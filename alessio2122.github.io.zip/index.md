---
layout: default
title: Inicio
---

# 🏗️**PÁGINA WEB EN DESARROLLO**🏗️

# Inicio

¡Hola! Bienvenido/a a la página oficial de Alessio2122 (yo).
Aquí es donde iré subiendo artículos sobre Minecraft y demás. Todo complementando a mis vídeos en el canal de YouTube (<a href="{{ 'https://youtube.com/@alessio2122mc?si=wJpvai4JHd4zwPSo' | relative_url }}">@Alessio2122MC</a>).
Algunas veces serán temas nuevo, otras más información a partir de un vídeo...

## Índice

[Artículos](posts/posts.md)<br>
[Proyectos](proyects/proyects.md)<br>
[Guías](guides/guides.md)<br>

## Últimos artículos

[_Nombre del último artículo_](_Enlace del último artículo_) <br>
[_Nombre del penúltimo artículo_](_Enlace al penúltimo artículo_)<br>
[_Nombre del antepenúltimo artículo_](_Enlace del antepenúltimo artículo_)<br>

## Proyectos actuales

[_Nombre del último proyecto_](_Enlace del último proyecto_)<br>
[_Nombre del penúltimo proyecto_](_Enlace al penúltimo proyecto_)<br>